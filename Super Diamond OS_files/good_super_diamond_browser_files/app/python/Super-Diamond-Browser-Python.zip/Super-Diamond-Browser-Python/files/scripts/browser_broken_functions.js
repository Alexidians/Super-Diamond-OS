window.open = function($url, $target, $features) {
 console.error("at window.open(" + $url + ", " + $target + ", " + $features + "): window.open() is broken here")
 return "at window.open(" + $url + ", " + $target + ", " + $features + "): window.open() is broken here"
}
open = function($url, $target, $features) {
 console.error("at open(" + $url + ", " + $target + ", " + $features + "): open() is broken here")
 return "at open(" + $url + ", " + $target + ", " + $features + "): open() is broken here"
}