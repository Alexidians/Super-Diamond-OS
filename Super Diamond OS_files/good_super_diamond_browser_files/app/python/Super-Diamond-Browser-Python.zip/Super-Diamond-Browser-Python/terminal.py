# to remember the idea.


def run_console():
    def console_thread():
        console = code.InteractiveConsole(locals=globals())
        console.interact(banner="Browser Console")

    thread = threading.Thread(target=console_thread)
    thread.start()

run_console()