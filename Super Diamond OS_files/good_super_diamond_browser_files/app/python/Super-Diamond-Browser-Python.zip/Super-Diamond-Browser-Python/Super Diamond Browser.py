import sys
import threading
import code
import subprocess
from PyQt5.QtGui import QIcon
from PyQt5.QtWidgets import QApplication, QMainWindow, QSizePolicy, QLineEdit, QPushButton, QVBoxLayout, QWidget, QTabWidget, QAction, QMenu, QInputDialog
from PyQt5.QtWebEngineWidgets import QWebEngineView
from PyQt5.QtCore import QUrl

runJSScript = "false"

class WebBrowser(QMainWindow):
    def __init__(self):
        try:
            super().__init__()

            self.browser_tabs = QTabWidget()
            self.browser_tabs.setTabsClosable(True)
            self.browser_tabs.tabCloseRequested.connect(self.close_tab)

            self.add_new_tab()

            self.container = QWidget()
            self.layout = QVBoxLayout(self.container)

            self.urlbar = QLineEdit()
            self.urlbar.returnPressed.connect(self.navigate_to_url)

            self.new_tab_btn = QPushButton("New Tab")
            self.new_tab_btn.clicked.connect(self.add_new_tab)
            self.layout.addWidget(self.new_tab_btn)

            self.search_btn = QPushButton("Go")
            self.search_btn.clicked.connect(self.navigate_to_url)

            self.layout.addWidget(self.urlbar)
            self.layout.addWidget(self.search_btn)
            self.layout.addWidget(self.browser_tabs)

            self.bookmarks = []  # Added bookmarks list
            self.bookmarks_menu = QMenu("Bookmarks", self)  # Added bookmarks menu

            self.load_bookmarks()  # Load bookmarks from file

            # Added actions for bookmarks
            add_bookmark_action = QAction("Add Bookmark", self)
            add_bookmark_action.triggered.connect(self.add_bookmark)
            self.bookmarks_menu.addAction(add_bookmark_action)

            show_bookmarks_action = QAction("Show Bookmarks", self)
            show_bookmarks_action.triggered.connect(self.show_bookmarks)
            self.bookmarks_menu.addAction(show_bookmarks_action)

            self.menuBar().addMenu(self.bookmarks_menu)  # Added bookmarks menu to the menu bar

            self.setGeometry(100, 100, 1280, 800)
            self.setWindowTitle("Super Diamond Browser")
            self.setCentralWidget(self.container)
            self.setWindowIcon(QIcon("files/icons/icon.ico"))
            self.interval(1, self.checkUserJavascript)
        except Exception as e:
            print(f"Super Diamond Browser: could not create WebBrowser object - {e}")
            self.vbs('x=msgbox("could not create WebBrowser object" ,0+16, "Super Diamond Browser")')

    def update_bookmarks_menu(self):
        # Clear the existing bookmarks menu
        self.bookmarks_menu.clear()

        # Populate the menu with the updated list of bookmarks
        for bookmark in self.bookmarks:
            bookmark_action = QAction(bookmark["title"], self)
            bookmark_action.triggered.connect(lambda checked, url=bookmark["url"]: self.navigate_to_bookmark(url))
            self.bookmarks_menu.addAction(bookmark_action)

        # Add actions for managing bookmarks
        self.bookmarks_menu.addSeparator()

        add_bookmark_action = QAction("Add Bookmark", self)
        add_bookmark_action.triggered.connect(self.add_bookmark)
        self.bookmarks_menu.addAction(add_bookmark_action)

        show_bookmarks_action = QAction("Show Bookmarks", self)
        show_bookmarks_action.triggered.connect(self.show_bookmarks)
        self.bookmarks_menu.addAction(show_bookmarks_action)

        # Update the menuBar with the new bookmarks menu
        self.menuBar().addMenu(self.bookmarks_menu)

    def show_bookmarks(self):
     self.bookmarks_menu.clear()

     for bookmark in self.bookmarks:
        bookmark_action = QAction(bookmark["title"], self)
        bookmark_action.triggered.connect(lambda checked, url=bookmark["url"]: self.navigate_to_bookmark(url))
        self.bookmarks_menu.addAction(bookmark_action)

     # Additional actions for bookmarks
     add_bookmark_action = QAction("Add Bookmark", self)
     add_bookmark_action.triggered.connect(self.add_bookmark)
     self.bookmarks_menu.addAction(add_bookmark_action)

     show_bookmarks_action = QAction("Show Bookmarks", self)
     show_bookmarks_action.triggered.connect(self.show_bookmarks)
     self.bookmarks_menu.addAction(show_bookmarks_action)

     self.menuBar().addMenu(self.bookmarks_menu)



    def load_bookmarks(self):
     try:
        with open("files/bookmarks.txt", "r", encoding="utf-8") as file:
            lines = file.readlines()

            for line in lines:
                # Split the line into title and url
                parts = line.strip().split(',')
                
                # Check if the line has the expected format
                if len(parts) == 2:
                    bookmark = {"title": parts[0], "url": parts[1]}
                    self.bookmarks.append(bookmark)
                else:
                    print(f"Skipping invalid line in bookmarks file: {line}")
     except Exception as e:
        print(f"Error loading bookmarks: {e}")



    def navigate_to_bookmark(self, url):
     if url.startswith("javascipt:"):
      javascript(url.lstrip("javascript:"))
     else:
        current_tab = self.browser_tabs.currentWidget()
        current_tab.setUrl(QUrl(url))

    def save_bookmarks(self):
     with open("files/bookmarks.txt", "w", encoding="utf-8") as file:
        # Clear the existing content in the file
        file.truncate(0)
        
        # Write the updated list of bookmarks
        for bookmark in self.bookmarks:
            file.write(f"{bookmark['title']},{bookmark['url']}\n")




    def add_bookmark(self):
        bookmark_url, ok = QInputDialog.getText(self, "Add Bookmark", "Enter bookmark URL:")
        if ok:
            bookmark_title, ok = QInputDialog.getText(self, "Add Bookmark", "Enter bookmark title:")
            if ok:
                bookmark = {"title": bookmark_title, "url": bookmark_url}
                self.bookmarks.append(bookmark)
                self.save_bookmarks()


    def interval(self, time, function):
        def interval_componement():
            while not self.closing:
                eval(function)
                time.sleep(time)

    def timeout(self, time, function):
        def timeout_componement():
            time.sleep(time)
            function()

    def setFileContent(self, path, content):
        def fileEditor():
            file = open(path, "w")
            file.write(content)
            file.close()

    def vbs(self, code):
        def vbs_executor():
            vbs_file = open("files/executors/vbs/execute.vbs", "w")
            vbs_file.write(code)
            vbs_file.close()
            return subprocess.Popen(['cscript', '//nologo', 'files/executors/vbs/execute.vbs'], stdout=subprocess.PIPE, stderr=subprocess.PIPE, shell=True)

    def add_new_tab(self):
        new_tab = QWebEngineView()
        new_tab.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
        new_tab.urlChanged.connect(self.url_change)
        self.browser_tabs.addTab(new_tab, "New Tab")
        new_tab.load(QUrl("about:blank"))

    def checkUserJavascript(self):
        if runJSScript == "true":
            runJSScript = "false"
            Javascript(JSScript)

    def close_tab(self, index):
        widget = self.browser_tabs.widget(index)
        if widget is not None:
            widget.deleteLater()

    def navigate_to_url(self):
        current_tab = self.browser_tabs.currentWidget()
        q = QUrl(self.urlbar.text())
        if current_tab:
            q = QUrl(self.urlbar.text())
            current_tab.setUrl(q)
        else:
            # If no tabs exist, create a new tab and navigate
            self.add_new_tab()
            self.navigate_to_url()

    def url_change(self, q):
        current_tab = self.browser_tabs.currentWidget()
        self.urlbar.setText(q.toString())
        self.urlbar.setCursorPosition(0)
        current_tab.page().runJavaScript("console.log('Page URL changed to:', window.location.href);")
        self.importUserPackages()
        self.loadConfig()
        self.importSuperDiamondPackages()

    def importUserPackages(self):
        try:
            UrlPackages = self.readFile("files/packages/user/url_packages.txt")
            FilePackages = self.readFile("files/packages/user/file_packages.txt")
        except:
            print("Browser ERR: failed to read User Package list files")

        try:
            UrlPackagesArray = UrlPackages.split(",")
            FilePackagesArray = FilePackages.split(",")
        except:
            print("Browser ERR: failed to convert User package lists to arrays")

        try:
            for url in UrlPackagesArray:
                self.javascript(self.source_code(url))

            for packageName in FilePackagesArray:
                self.javascript(self.readFile("files/packages/users/", packageName))
        except:
            print("Browser ERR: failed to run User packages from array")

    def loadConfig(self):
        try:
            self.javascript_from_file("files/config/navigator.js")
        except:
            print("Browser ERR: could not Load Config for Page")

    def importSuperDiamondPackages(self):
        try:
            self.javascript(self.source_code(self.readFile("files/packages/system/super_diamond_programing_language.txt")))
            self.javascript(self.source_code(self.readFile("files/packages/system/super_diamond_html_elements.txt")))
        except:
            print("Browser ERR: could not Import Super Diamond Packages")
    
    def close_tab(self, index):
        widget = self.browser_tabs.widget(index)
        if widget is not None:
            widget.deleteLater()

    def javascript(self, code):
        try:
            return self.browser_tabs.currentWidget().page().runJavaScript(code, javascript_callback)
        except:
            print("Browser ERR: could not run JS From Code")

    def python(self, code):
        try:
            return eval(code)
        except:
            print("Browser ERR: could not run Python From String at self.python(", code, ")")

    def javascript_from_file(self, file_path):
        try:
            js_file = open(file_path, 'r', encoding='utf-8')
            js_code = js_file.read()
            js_file.close()
            page = self.browser_tabs.currentWidget().page()
            return page.runJavaScript(js_code)
        except:
            print("Browser ERR: could not Execute Local File")

    def readFile(self, file_path):
        def fileReader():
            try:
                file = open(file_path, 'r', encoding='utf-8')
                file_content = file.read()
                file.close()
                return file_content
            except:
                print("Super Diamond Browser: Could Not Read File Content from ", file_path)
                self.vbs('x=msgbox("Could Not Read File Content from ', file_path, '" ,0+16, "Super Diamond Browser")')


    def javascript_callback(result):
     print("JavaScript result:", result)


    def quit(self):
     app.quit()


    def loadHomePage(self):
     try:
        fileType = self.readFile("files/homepage/type.txt")
        filePath = "reading..."
        filePath = "file/homepage/home." + fileType
        self.browser_tabs.currentWidget().setUrl(QUrl(filePath))
     except:
        print("Browser ERR: could not load Homepage. showing a blank page")


def run_console():
    def console_thread():
        console = code.InteractiveConsole(locals=globals())
        console.interact(banner="Browser Console")

    thread = threading.Thread(target=console_thread)
    thread.start()


if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = WebBrowser()
    window.show()
    run_console()
    sys.exit(app.exec_())
