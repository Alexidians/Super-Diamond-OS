try:
 import sys
 import threading
 import code
 import requests
 from PyQt5.QtGui import QIcon
 from PyQt5.QtWidgets import QApplication, QMainWindow, QSizePolicy, QLineEdit, QPushButton, QVBoxLayout, QWidget
 from PyQt5.QtWebEngineWidgets import QWebEngineView
 from PyQt5.QtCore import QUrl
except:
 print("Browser ERR: could not Import Python Packages. App could not be runned")



class WebBrowser(QMainWindow):
    def __init__(self):
        try:
         super().__init__()

         self.browser = QWebEngineView()
         self.browser.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
         self.browser.urlChanged.connect(self.url_change)

         self.container = QWidget()
         self.layout = QVBoxLayout(self.container)

         self.urlbar = QLineEdit()
         self.urlbar.returnPressed.connect(self.navigate_to_url)

         self.search_btn = QPushButton("Go")
         self.search_btn.clicked.connect(self.navigate_to_url)

         self.layout.addWidget(self.urlbar)
         self.layout.addWidget(self.search_btn)
         self.layout.addWidget(self.browser)

         self.setGeometry(100, 100, 1280, 800)
         self.setWindowTitle("Super Diamond Browser")

         self.setCentralWidget(self.container)
         self.setWindowIcon(QIcon("files/icons/icon.ico"))
        except:
         print("Browser ERR: could not load Browser Window. App can not be executed")

    def navigate_to_url(self):
     try:
        q = QUrl(self.urlbar.text())
        print("Navigated to " + q.toString())
        self.browser.setUrl(q)
     except:
      print("Browser ERR: could not Update Urlbar Url for this Page")

    def source_code(self, url):
     try:
      response = requests.get(url)
      source_code = response.text
      return source_code
     except:
      print("BROWSER ERR: could not get source code of ", url, " returning undefined")

    def update_urlbar(self, q):
     try:
        self.urlbar.setText(q.toString())
        self.urlbar.setCursorPosition(0)
     except:
      print("Browser ERR: could not Update Urlbar Url for this Page")

    def update_title(self):
     try:
        title = self.browser.page().title()
        self.setWindowTitle("%s - Super Diamond Browser" % title)
     except:
      print("Browser ERR: could not Update Title for this Page")


    def url_change(self, q):
     self.update_urlbar(q)
     self.update_title()
     print("Changed Page To ", q.toString())
     self.loadConfig()
     self.importSuperDiamondPackages()

    def loadConfig(self):
     try:
      self.javascript_from_file("files/config/navigator.js")
     except:
      print("Browser ERR: could not Load Config for Page")

    def importSuperDiamondPackages(self):
     try:
      self.javascript(self.source_code(self.readFile("files/packages/system/super_diamond_programing_language.txt")))
      self.javascript(self.source_code(self.readFile("files/packages/system/super_diamond_html_elements.txt")))
     except:
      print("Browser ERR: could not Import Super Diamond Packages")

    def javascript(self, code):
     try:
      return self.browser.page().runJavaScript(code, javascript_callback)
     except:
      print("Browser ERR: could not run JS From Code")

    def python(self, code):
     try:
      return eval(code)
     except:
      print("Browser ERR: could not run Python From String at self.python(", code, ")")

    def javascript_from_file(self, file_path):
     try:
      js_file = open(file_path, 'r', encoding='utf-8')
      js_code = js_file.read()
      js_file.close()
      page = self.browser.page()
      return page.runJavaScript(js_code)
     except:
      print("Browser ERR: could not Execute Local File")

    def readFile(self, file_path):
     try:
      file = open(file_path, 'r', encoding='utf-8')
      file_content = file.read()
      file.close()
      return file_content
     except:
      print("Browser ERR: could not read File Content. returning undefined")
        
def javascript_callback(result):
    print("JavaScript result:", result)

def quit(self):
 app.close()

def loadHomePage(self):
 try:
  fileType = self.readFile("settings/homepage/type.txt")
  filePath = "reading..."
  filePath = "settings/homepage/home.", fileType
  self.browser.setUrl(QUrl(filePath))
 except:
  print("Browser ERR: could not load Homepage. showing blank page")

def run_console():
    def console_thread():
     console = code.InteractiveConsole(locals=globals())
     console.interact(banner="Browser Console")
     thread = threading.Thread(target=console_thread)
     thread.start()

try:
 if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = WebBrowser()
    window.show()
    run_console()
    
    app.exec_()
except:
 print("Browser ERR: could not Run App. App does not work")