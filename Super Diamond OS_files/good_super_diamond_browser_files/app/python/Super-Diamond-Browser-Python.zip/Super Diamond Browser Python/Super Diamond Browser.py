import sys
import threading
import code
from PyQt5.QtGui import QIcon
from PyQt5.QtWidgets import QApplication, QMainWindow, QSizePolicy, QLineEdit, QPushButton, QVBoxLayout, QWidget
from PyQt5.QtWebEngineWidgets import QWebEngineView
from PyQt5.QtCore import QUrl
cmd = "undefined"

class WebBrowser(QMainWindow):
    def __init__(self):
        super().__init__()

        self.browser = QWebEngineView()
        self.browser.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
        self.browser.urlChanged.connect(self.url_change)

        self.container = QWidget()
        self.layout = QVBoxLayout(self.container)

        self.urlbar = QLineEdit()
        self.urlbar.returnPressed.connect(self.navigate_to_url)

        self.search_btn = QPushButton("Go")
        self.search_btn.clicked.connect(self.navigate_to_url)

        self.layout.addWidget(self.urlbar)
        self.layout.addWidget(self.search_btn)
        self.layout.addWidget(self.browser)

        self.setGeometry(100, 100, 1280, 800)
        self.setWindowTitle("Super Diamond Browser")
        self.setWindowIcon(QIcon("files/icons/icon.ico"))

        self.setCentralWidget(self.container)
        cmd = self

    def navigate_to_url(self):
        q = QUrl(self.urlbar.text())
        print("Navigated to " + q.toString())
        self.browser.setUrl(q)

    def update_urlbar(self, q):
        self.urlbar.setText(q.toString())
        self.urlbar.setCursorPosition(0)

    def update_title(self):
        title = self.browser.page().title()
        self.setWindowTitle("%s - Super Diamond Browser" % title)

    def url_change(self, q):
     cmd = self
     self.update_urlbar(q)
     self.update_title()
     print("Changed Page To ", q.toString())
     self.loadConfig()
     self.importSuperDiamondPackages()

    def loadConfig(self):
     self.javascript_from_file("files/config/navigator.js")

    def importSuperDiamondPackages(self):
     self.javascript_from_file("files/packages/system/super_diamond_programing_language.js")
     self.javascript_from_file("files/packages/system/super_diamond_html_elements.js")

    def javascript(self, code):
     return self.browser.page().runJavaScript(code, javascript_callback)

    def python(self, code):
     return eval(code)

    def javascript_from_file(self, file_path):
     js_file = open(file_path, 'r', encoding='utf-8')
     js_code = js_file.read()
     js_file.close()
     page = self.browser.page()
     return page.runJavaScript(js_code)

    def readFile(self, file_path):
     file = open(file_path, 'r', encoding='utf-8')
     file_content = file.read()
     file.close()
     return file_content
        
def javascript_callback(result):
    print("JavaScript result:", result)

def quit(self):
 app.close()

def loadHomePage(self):
 fileType = self.readFile("settings/homepage/type.txt")
 filePath = "reading..."
 filePath = "settings/homepage/home.", fileType
 self.browser.setUrl(QUrl(filePath))

def run_console():
    def console_thread():
        console = code.InteractiveConsole(locals=globals())
        console.interact(banner="Browser Console")

    thread = threading.Thread(target=console_thread)
    thread.start()

if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = WebBrowser()
    window.show()
    
    run_console()
    
    app.exec_()