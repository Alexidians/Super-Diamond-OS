import sys
import threading
import code
from PyQt5.QtGui import QIcon
from PyQt5.QtWidgets import QApplication, QMainWindow, QSizePolicy, QLineEdit, QPushButton, QVBoxLayout, QWidget
from PyQt5.QtWebEngineWidgets import QWebEngineView
from PyQt5.QtCore import QUrl

class WebBrowser(QMainWindow):
    def __init__(self):
        super().__init__()

        self.browser = QWebEngineView()
        self.browser.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
        self.browser.urlChanged.connect(self.update_urlbar)

        self.container = QWidget()
        self.layout = QVBoxLayout(self.container)

        self.urlbar = QLineEdit()
        self.urlbar.returnPressed.connect(self.navigate_to_url)

        self.search_btn = QPushButton("Go")
        self.search_btn.clicked.connect(self.navigate_to_url)

        self.layout.addWidget(self.urlbar)
        self.layout.addWidget(self.search_btn)
        self.layout.addWidget(self.browser)

        self.status = self.statusBar()
        self.browser.urlChanged.connect(self.update_title)

        self.setGeometry(100, 100, 1280, 800)
        self.setWindowTitle("Super Diamond Browser")
        self.setWindowIcon(QIcon("files/icons/icon.ico"))

        self.setCentralWidget(self.container)

    def navigate_to_url(self):
        q = QUrl(self.urlbar.text())
        if q.scheme() == "":
            q.setScheme("http")

        self.browser.setUrl(q)

    def update_urlbar(self, q):
        self.urlbar.setText(q.toString())
        self.urlbar.setCursorPosition(0)

    def update_title(self):
        title = self.browser.page().title()
        self.setWindowTitle("%s - Super Diamond Browser" % title)

    def javascript(code, self):
     return self.browser.page().runJavaScript(code)

    def python(code):
     return eval(code)


def run_console():
    def console_thread():
        console = code.InteractiveConsole(locals=globals())
        console.interact(banner="Browser Console (alpha)")

    thread = threading.Thread(target=console_thread)
    thread.start()

if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = WebBrowser()
    window.show()
    
    run_console()
    
    app.exec_()