var SuperDiamondHTMLElements = document.createElement("script")
SuperDiamondHTMLElements.src = "https://alexidians.github.io/Super-Diamond-Elements/elements.js"
document.body.appendChild(SuperDiamondHTMLElements)
SuperDiamondHTMLElements = undefined