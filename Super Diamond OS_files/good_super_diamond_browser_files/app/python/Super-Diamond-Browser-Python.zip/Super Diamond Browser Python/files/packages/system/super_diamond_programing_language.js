var SuperDiamondPrograming = document.createElement("script")
SuperDiamondPrograming.src = "https://alexidians.github.io/Super-Diamond-Programing-Language/programing-language.js"
document.body.appendChild(SuperDiamondPrograming)
SuperDiamondPrograming = undefined